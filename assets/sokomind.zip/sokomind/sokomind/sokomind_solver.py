import time, copy
from collections import deque
from puzzle import Puzzle
from sokomind_algorithms import dfs, bfs, greedy
from sokomind_heuristics import manhattan, heatmap, deadzones
from game_state import State, Direction


class SokomindSolver:

    def __init__(self, algorithm, stats=False, replay=False):
        """
            A customizable solver, which invokes a supplied search algorithm with configured options.
            
            Params:
                algorithm: A function(State) -> State, int; usually from sokomind_algorithms.py
                stats: Boolean; determines whether execution time stats should be output
                replay: Boolean; determines whether, after a solve is found, if the solve sequence
                        should be printed

        """
        self.solve = self.measure_stats(algorithm)
        self.replay = replay
        self.stats = stats

    def measure_stats(self, algorithm):
        """
        Wrapper. Extends the functionality of the chosen algorithm based off
        supplied commandline arguments. Can output time stats, or can configure how
        the solution is output.
        """
        def inner(initial_state): 

            start_time = time.time()
            solution_state, visited_state_count = algorithm(initial_state)
            end_time = time.time()

            if solution_state is None:
                print("No Solution...")
            elif self.replay: # --replay was a commandline argument
                sequence = deque()
                curr_state = solution_state
                while curr_state is not None:
                    # Gets every State in the solve sequence.
                    sequence.append(curr_state)
                    curr_state = curr_state._parent
                while sequence:
                    # Outputs every State in the solve sequence in sequential order.
                    curr_state = sequence.pop()
                    last_move = ""
                    match curr_state._last_move:
                        case Direction.NORTH: last_move = "NORTH"
                        case Direction.SOUTH: last_move = "SOUTH"
                        case Direction.EAST:  last_move = "EAST"
                        case Direction.WEST:  last_move = "WEST"
                    print(f"\nMove: {curr_state.move_number}\t Direction: {last_move}")
                    print(curr_state.grid)
            else: 
                print(f"Completed in {solution_state.move_number} moves")
                print(solution_state.grid)
            
            if self.stats: # --stats was a commandline argument
                print(f"Visited: {visited_state_count} States!")
                time_span = end_time - start_time
                match time_span:
                    case _ if  time_span < 30:
                        print(f"Runtime: {'{0:.8}'.format((time_span)*1000)} ms")
                    case default:
                        print(f"Runtime: {time_span//60} minutes, and {time_span%60} seconds")

            return solution_state
        return inner


