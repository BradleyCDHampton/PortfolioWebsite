import argparse
from puzzle import Puzzle
from game_state import State
from sokomind_solver import SokomindSolver
from sokomind_algorithms import dfs, bfs, greedy
from sokomind_heuristics import manhattan, heatmap, deadzones


# Command Line Arguments
parser = argparse.ArgumentParser(prog='__main__.py')
parser.add_argument('filepath', 
                    help='The file path for the puzzle to be loaded.')
parser.add_argument('algorithm',
                    choices=['dfs', 'bfs', 'greedy', 'astar'],
                    help="The search algorithm to apply to the puzzle.")
parser.add_argument('--heuristic',
                    choices=['manhattan', 'heatmap','deadzones'],
                    help="The heuristic to apply to the algorithm (only works when algorithm == greedy or astar)")
parser.add_argument('--stats', action='store_true', help="stats  - show runtime statistics only")
parser.add_argument('--replay', action='store_true', help="show a replay to the solution state")


def main():
    args = parser.parse_args()

    puzzle = Puzzle(args.filepath)
    state = State(puzzle)

    # Translates commandline args to human-readable text for output.
    algorithm_dict = {'dfs': "Depth-First Search",
                      'bfs': "Breadth-First Search",
                      'greedy': "Greedy Search",
                      'astar': "A* Search",
                      'manhattan': "Manhattan",
                      'heatmap': "Heatmap",
                      'deadzones': "Deadzones"}
    
    my_heuristic = None
    
    if args.heuristic is None: args.heuristic = 'deadzones' # Default Heuristic, if one is not specified at commandline
    match args.heuristic:
        case 'manhattan': my_heuristic = manhattan
        case 'heatmap': my_heuristic = heatmap
        case 'deadzones': my_heuristic = deadzones

    match args.algorithm:
        case 'dfs': algo = dfs
        case 'bfs': algo = bfs
        case 'greedy': algo = greedy(my_heuristic)
        case 'astar' : algo = greedy(my_heuristic, a_star=True)

    solver = SokomindSolver(algo, stats=args.stats, replay=args.replay)

    if args.algorithm in ['dfs','bfs']:
        print(f"\n{algorithm_dict[args.algorithm]}:")
    else:
        print(f"\n{algorithm_dict[args.algorithm]} with {algorithm_dict[args.heuristic]} Heuristic:")

    solution = solver.solve(state) 

if __name__ == "__main__":
    main()