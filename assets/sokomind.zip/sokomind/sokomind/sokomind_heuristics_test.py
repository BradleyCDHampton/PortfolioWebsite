import pytest, csv
import numpy as np
from pathlib import Path

from game_state import State
from puzzle import Puzzle

from sokomind_heuristics import manhattan, heatmap, deadzones
from sokomind_solver import SokomindSolver
from sokomind_algorithms import greedy

#Setup

@pytest.fixture
def tiny():
    return State(Puzzle(r"sokomind\puzzles\1_tiny.txt"))

all_puzzles = []
puzzles_directory = Path('sokomind\puzzles')

with open('expected/expected_values.csv', mode='r') as file:
    csv_reader = csv.DictReader(file)
    temp_data = {row['puzzle_path']: row for row in csv_reader}
    
    for puzzle_path in puzzles_directory.iterdir():
        new_state = State(Puzzle(puzzle_path))
        all_puzzles.append(new_state)
        
#Tests

@pytest.mark.parametrize("state_and_expected", [(0,5),(1,18),(2,34)])
def test_manhattan(state_and_expected):
    state_num, expected = state_and_expected

    assert manhattan(all_puzzles[state_num]) == expected

@pytest.mark.parametrize("state_and_expected", [(0,5),(1,18),(2,34)])
def test_compare_heatmap_with_manhattan_initial_state(state_and_expected):
    state_num, expected = state_and_expected

    temp = {}

    heatmap_cost = heatmap(all_puzzles[state_num], temp)
    manhattan_cost = manhattan(all_puzzles[state_num])

    assert manhattan_cost <= heatmap_cost

def test_compare_heatmap_with_manhattan_solve_sequence(tiny):

    temp = {}

    solver = SokomindSolver(greedy(heuristic_func=heatmap))
    solution = solver.solve(tiny)

    # For every step of the solution, the Heatmap cost should be more than the
    # Manhattan cost, since the only difference is Heatmap does not ignore obstacles.
    while solution is not None:
        heatmap_cost = heatmap(solution, temp)
        manhattan_cost = manhattan(solution)
        assert heatmap_cost >= manhattan_cost
        solution = solution._parent

#Test Heatmap
def test_heatmap_generation(tiny):

    hm = {}
    heatmap(tiny, hm)
    
    expected_heatmaps = {}

    expected_heatmaps['X'] = np.array([[-1,-1,-1,-1,-1,-1],
                                       [-1, 5, 4, 5, 6,-1],
                                       [-1, 4, 3,-1, 5,-1],
                                       [-1,-1, 2, 3, 4,-1],
                                       [-1, 0, 1, 2, 3,-1],
                                       [-1,-1,-1,-1,-1,-1]])
    
    expected_heatmaps['A'] = np.array([[-1,-1,-1,-1,-1,-1],
                                       [-1, 4, 3, 4, 5,-1],
                                       [-1, 3, 2,-1, 4,-1],
                                       [-1,-1, 1, 2, 3,-1],
                                       [-1, 1, 0, 1, 2,-1],
                                       [-1,-1,-1,-1,-1,-1]])

    assert len(hm) == len(expected_heatmaps)

    for key, val in expected_heatmaps.items():
        assert key in hm
        assert np.array_equal(hm[key], val)


#Test Deadzone generation

def test_deadzone_generation(tiny):

    hm = {}
    deadzones(tiny, hm)
    expected_heatmaps = {}

    expected_heatmaps['X'] = np.array([[-1,-1,-1,-1,-1,-1],
                                       [-1,-1,-1,-1,-1,-1],
                                       [-1,-1, 3,-1,-1,-1],
                                       [-1,-1, 2, 3,-1,-1],
                                       [-1, 0, 1, 2,-1,-1],
                                       [-1,-1,-1,-1,-1,-1]])
    
    expected_heatmaps['A'] = np.array([[-1,-1,-1,-1,-1,-1],
                                       [-1,-1,-1,-1,-1,-1],
                                       [-1,-1, 2,-1,-1,-1],
                                       [-1,-1, 1, 2,-1,-1],
                                       [-1,-1, 0, 1,-1,-1],
                                       [-1,-1,-1,-1,-1,-1]])

    assert len(hm) == len(expected_heatmaps)

    for key, val in expected_heatmaps.items():
        assert key in hm
        assert np.array_equal(hm[key], val)