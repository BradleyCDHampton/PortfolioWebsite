
from enum import Enum
from collections import deque
from puzzle import Puzzle, Entity
import copy

class Direction(Enum):
    '''Ways the Robot can move'''
    NORTH = (-1,0)
    SOUTH = (1,0)
    EAST = (0,1)
    WEST = (0,-1)

class State(Puzzle):
    """
        A single scenario on a Sokomind Puzzle, derived from legal moves extending
        from the initial Puzzle.
    """

    def __init__(self, puzzle: Puzzle):

        self._grid = puzzle._grid

        self._storages = puzzle.storages
        self._blocks = puzzle.blocks
        self._paired_entities = puzzle.paired_entities
        self._paired_block_coords = puzzle._paired_block_coords
        self._paired_storage_coords = puzzle._paired_storage_coords
        self._robot_coordinates = puzzle.starting_coordinates
        self._parent = None
        self._move_count = 0
        self._last_move = None
        self._successors = []
    
    @property
    def move_number(self):
        '''Initial State is considered move 0'''
        return self._move_number

    def is_valid_move(self, direction):
        """
            Evaluates whether the robot can move in this direction.

            Returns:
                True if the space in that direction is open
                True if a block is in this space  and can be pushed to the next open space
                False otherwise
        """
        x, dx = self._robot_coordinates[0], direction.value[0]
        y, dy = self._robot_coordinates[1], direction.value[1]

        if self.is_passable(x+dx,y+dy):
            return True
        elif self.is_pushable(x+dx,y+dy) and self.is_passable(x+(2*dx),y+(2*dy)):
            return True
        else:
            return False

    @property
    def robot_coordinates(self):
        '''Return tuple: (x,y)'''
        return self._robot_coordinates

    @property
    def parent(self):
        '''Returns State or None'''
        return self._parent
    
    @property
    def successors(self):
        '''Returns list:'''
        return self._successors

    @property
    def grid(self):
        return super().grid
    
    def _set_grid(self, x, y, new_value):
        """
            Assigns a new value to grid[x][y], updating tracked positions of
            Blocks as neccessary.
        """
     
        old_value = self.grid[x][y]
        entity = self.entity_at(x,y)

        # Evaluate whether any records of Blocks in given positions need to be deleted.
        match entity:
            case Entity.BLOCK:
                self._blocks.remove((x,y))
            case Entity.BLOCK_PAIRED:
                del self._paired_block_coords[(x,y)]
        # Evaluate whether the assignment results in any new Block/Robot positions needing to be logged.
        match new_value:
            case 'R':
                self._robot_coordinates = (x,y)
            case 'X':
                self._blocks.add((x,y))
            case _ if new_value.isupper() and new_value not in {'O','R','S'}:
                self._paired_block_coords[(x,y)] = new_value

    @property
    def move_number(self):
        '''Returns int: the number of moves that have taken place to reach this state.'''
        return self._move_count
    
    @property
    def moves(self):
        '''Returns list: [Direction] the entire sequence ofo moves up to this point O(n)'''

        move_list = deque()

        curr_state = self
        while (curr_state._parent != None):
            move_list.appendleft(curr_state._last_move)
            curr_state = curr_state._parent
        return list(move_list)

    def __eq__(self, other):
        '''Invokes Puzzle.__eq__'''
        if isinstance(other, State):
            return super().__eq__(other)
        return False
    
    def __lt__(self, other):
        '''Returns: True if the current state has taken fewer moves than other. False otherwise.'''
        if isinstance(other, State):
            return self != other and self.move_number < other.move_number

    def __hash__(self):
        return super().__hash__()

    def generate_successors(self):
        '''Produces all legal moves in self._successors'''

        for direction in Direction:
            if self.is_valid_move(direction):
                self._successors.append(self._generate_successor(direction))

    def is_solved(self):
        '''Returns True if all blocks are in the correct storages'''

        for block in self.blocks:
            if block not in self.storages:
                return False
        for key, val in self._paired_block_coords.items(): # key = (x,y)
            if (key not in self._paired_storage_coords or
                self._paired_storage_coords[key] != val.lower()):
                return False
        return True
        
    def _generate_successor(self, direction):
        """
            Generates the state where the robot moves in given direction.

            Precondition:
                self.is_valid_move(direction) == True

            Returns:
                The state where the robot has moved in the given direction,
                possibly pushing a block in the process.
        """
        x, dx = self._robot_coordinates[0], direction.value[0]
        y, dy = self._robot_coordinates[1], direction.value[1]        

        successor = copy.copy(self) # don't like this; make a hashmap perhaps
        
        successor._paired_block_coords = copy.deepcopy(self._paired_block_coords)
        successor._blocks = copy.deepcopy(self._blocks)

        successor._parent = self
        successor._successors = []

        # Update moves made to get to this state.
        successor._last_move = direction
        successor._move_count += 1
        successor._parent = self

        if not successor.is_passable(x+dx,y+dy):
            successor._set_grid(2*dx+x,2*dy+y, successor.grid[x+dx][y+dy])

        successor._set_grid(x+dx, y+dy, 'R')
        successor._set_grid(x,y, self._grid[x][y])

        return successor