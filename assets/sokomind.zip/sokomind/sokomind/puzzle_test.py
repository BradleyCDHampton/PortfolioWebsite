import csv, ast, pytest
from puzzle import Puzzle, Entity

#Setup

all_puzzles = []
expected_results = {}

with open('expected/expected_values.csv', mode='r') as file:
    csv_reader = csv.DictReader(file)

    for row in csv_reader:
        new_puzzle = Puzzle(row['puzzle_path'])
        all_puzzles.append(new_puzzle)
        expected_results[new_puzzle] = row

#Tests

@pytest.mark.parametrize("puzzle", all_puzzles)
def test_dimension_getters(puzzle):

    assert puzzle.dimensions == ast.literal_eval(expected_results[puzzle]['dimensions'])
    assert puzzle.height == puzzle.dimensions[0]
    assert puzzle.width == puzzle.dimensions[1]

@pytest.mark.parametrize("puzzle", all_puzzles)
def test_grid_construction(puzzle):

    # Initialized grid matches the source text file.
    with open(expected_results[puzzle]['puzzle_path'], mode='r') as source_file:
        source_text = source_file.readlines()
        source_text = [line.strip() for line in source_text]
        assert puzzle.dimensions[0] == len(source_text)
        for i in range(len(source_text)):
            assert source_text[i] == ''.join(puzzle.grid[i])


@pytest.mark.parametrize("puzzle", all_puzzles)
def test_bounds_checking(puzzle):
    max_row = puzzle.height-1
    max_col = puzzle.width-1

    # In Bounds
    assert puzzle.in_bounds(0,0) == True
    assert puzzle.in_bounds(0,max_col) == True
    assert puzzle.in_bounds(max_row, 0) == True
    assert puzzle.in_bounds(max_row, max_col) == True

    # Out of Bounds
    assert puzzle.in_bounds(-1,0) == False
    assert puzzle.in_bounds(0,-1) == False
    assert puzzle.in_bounds(max_row+1,0) == False
    assert puzzle.in_bounds(0,max_col+1) == False

def test_detect_objects():
    tiny = Puzzle(r"sokomind\puzzles\1_tiny.txt")
    assert tiny.entity_at(0,0) == Entity.OBSTACLE
    assert tiny.entity_at(1,3) == Entity.ROBOT
    assert tiny.entity_at(1,1) == Entity.EMPTY
    assert tiny.entity_at(2,2) == Entity.BLOCK
    assert tiny.entity_at(3,3) == Entity.BLOCK_PAIRED
    assert tiny.entity_at(4,1) == Entity.STORAGE
    assert tiny.entity_at(4,2) == Entity.STORAGE_PAIRED

@pytest.mark.parametrize("puzzle", all_puzzles)
def test_object_recognition_OLD(puzzle):
    grid = puzzle.grid
    for x in range(len(grid)):
        for y in range(len(grid[0])):
            letter = grid[x][y]

            # Contrapositive Law: p -> q == q or !p
            assert puzzle.entity_at(x,y) == Entity.OBSTACLE or letter != 'O'
            assert puzzle.entity_at(x,y) == Entity.ROBOT or letter != 'R'
            assert puzzle.entity_at(x,y) == Entity.EMPTY or letter != ' '
            assert puzzle.entity_at(x,y) == Entity.BLOCK or letter != 'X'
            assert puzzle.entity_at(x,y) == Entity.STORAGE or letter != 'S'
            assert puzzle.entity_at(x,y) == Entity.BLOCK_PAIRED or letter in {'R','O','S','X'} or not letter.isupper()
            assert puzzle.entity_at(x,y) == Entity.STORAGE_PAIRED or not letter.islower()

def test_is_passable():
    tiny = Puzzle(r"sokomind\puzzles\1_tiny.txt")
    assert tiny.entity_at(0,0) == Entity.OBSTACLE and tiny.is_passable(0,0) == False
    assert tiny.entity_at(1,3) == Entity.ROBOT and tiny.is_passable(1,3) == True
    assert tiny.entity_at(1,1) == Entity.EMPTY and tiny.is_passable(1,1) == True 
    assert tiny.entity_at(2,2) == Entity.BLOCK and tiny.is_passable(2,2) == False 
    assert tiny.entity_at(3,3) == Entity.BLOCK_PAIRED and tiny.is_passable(3,3) == False
    assert tiny.entity_at(4,1) == Entity.STORAGE and tiny.is_passable(4,1) == True
    assert tiny.entity_at(4,2) == Entity.STORAGE_PAIRED and tiny.is_passable(4,2) == True
    assert tiny.in_bounds(-1,-1) == False and tiny.is_passable(-1,-1) == False

def test_is_pushable():
    tiny = Puzzle(r"sokomind\puzzles\1_tiny.txt")
    assert tiny.entity_at(0,0) == Entity.OBSTACLE and tiny.is_pushable(0,0) == False
    assert tiny.entity_at(1,3) == Entity.ROBOT and tiny.is_pushable(1,3) == False
    assert tiny.entity_at(1,1) == Entity.EMPTY and tiny.is_pushable(1,1) == False
    assert tiny.entity_at(2,2) == Entity.BLOCK and tiny.is_pushable(2,2) == True 
    assert tiny.entity_at(3,3) == Entity.BLOCK_PAIRED and tiny.is_pushable(3,3) == True
    assert tiny.entity_at(4,1) == Entity.STORAGE and tiny.is_pushable(4,1) == False
    assert tiny.entity_at(4,2) == Entity.STORAGE_PAIRED and tiny.is_pushable(4,2) == False
    assert tiny.in_bounds(-1,-1) == False and tiny.is_pushable(-1,-1) == False

@pytest.mark.parametrize("puzzle", all_puzzles)
def test_find_robot(puzzle):
    assert puzzle.starting_coordinates == ast.literal_eval(expected_results[puzzle]['starting_coordinates'])

@pytest.mark.parametrize("puzzle", all_puzzles)
def test_find_blocks(puzzle):
    assert puzzle.blocks == ast.literal_eval(expected_results[puzzle]['block_coords'])

@pytest.mark.parametrize("puzzle", all_puzzles)
def test_find_storage(puzzle):
    assert puzzle.storages == ast.literal_eval(expected_results[puzzle]['storage_coords'])

@pytest.mark.parametrize("puzzle", all_puzzles)
def test_find_paired_entities(puzzle):
    assert puzzle.paired_entities == ast.literal_eval(expected_results[puzzle]['paired_objects'])