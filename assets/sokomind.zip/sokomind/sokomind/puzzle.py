import numpy as np
from enum import Enum

class Entity(Enum):
    '''Types of objects found in the grid'''
    ROBOT = 'R'       
    OBSTACLE = 'O'      
    EMPTY = ' '         
    BLOCK = 'X'       
    STORAGE = 'S'
    BLOCK_PAIRED = 'A'
    STORAGE_PAIRED = 'a'

    
class Puzzle:
    """
        A grid representation of a Sokomind puzzle.           
    """
   
    def __init__(self, filename):
        
        temp = np.genfromtxt(filename, delimiter='\n', dtype=str)
        self._grid = temp.view('U1').reshape((temp.size, -1))

        self._robot_coordinates = (-1,-1)
        self._storages = set()
        self._blocks = set()
        self._paired_entities = {}
        self._paired_block_coords = {}
        self._paired_storage_coords = {}

        self._find_key_entities()

    @property
    def grid(self):
        '''Returns an n x m array of str'''
        temp = np.copy(self._grid)
        for coords in self._blocks:
            x, y = coords
            temp[x][y] = 'X'
        for coords, letter in self._paired_block_coords.items():
            x, y = coords
            temp[x][y] = letter
        x,y = self._robot_coordinates
        temp[x][y] = 'R'
        return temp

    @property
    def dimensions(self):
        '''Returns a tuple: (int: rows, int: columns)'''
        return np.shape(self.grid)
    
    @property
    def height(self):
        '''Returns the number of rows in the grid'''
        return self.dimensions[0]
    
    @property
    def width(self):
        '''Returns the number of columns in the grid'''
        return self.dimensions[1]
    
    @property
    def starting_coordinates(self):
        '''Returns a tuple: (int: row, int: column)'''
        return self._robot_coordinates
    
    @property
    def storages(self):
        '''Returns a list of tuples: (x,y)'''
        return self._storages
    
    @property
    def blocks(self):
        '''Returns a list of tuples: (x,y)'''
        return self._blocks
    
    @property
    def paired_entities(self):
        '''Returns a map of tuples: {str : tuple}'''
        return self._paired_entities

    def __eq__(self, other):
        '''Returns True if both States have the same grid and the blocks and robot are in the same positions'''
        if isinstance(other, Puzzle):
            return (np.array_equal(self._grid, other._grid) and
                    self._paired_block_coords == other._paired_block_coords and
                    self._paired_storage_coords == other._paired_storage_coords and
                    self._robot_coordinates == other._robot_coordinates)
        return False
    
    def __hash__(self):
        '''Elementwise hash of self._blocks and self._paired_block_coords'''
        return hash((tuple(sorted(self._blocks)), tuple(sorted(self._paired_block_coords))))

    def in_bounds(self, x, y):
        '''Returns True if the (x,y) is in the grid'''
        return (x >= 0 and x < self.height and
                y >= 0 and y < self.width)

    def is_passable(self,x,y):
        '''Returns True if (x,y) is in-bounds and doesn't have an obstacle, block, or robot'''
        entity = self.entity_at(x,y)
        return self.in_bounds(x,y) and entity not in {Entity.OBSTACLE, Entity.BLOCK, Entity.BLOCK_PAIRED}
    
    def is_pushable(self,x,y):
        '''Returns True if (x,y) is in-bounds and has a block.'''
        entity = self.entity_at(x,y)
        return self.in_bounds(x,y) and entity in {Entity.BLOCK, Entity.BLOCK_PAIRED}
    
    def _find_key_entities(self):
        """Initialization step. Logs the location of moveable entities on the grid and scrubs them
        from the grid.
        
            Pre:
                len(self._blocks) == 0 and
                len(self._storages) == 0 and
                len(self._paired_entities) == 0 and
                len(self._paired_block_coords) == 0 and
                len(self._paired_storage_coords) == 0 and
                self._robot_coordinates is None and
                self._grid is not None and
                exactly 1 'R' is in self._grid

            Post:
                self._grid only contains characters in {'O','S'} or characters.islower() and
                self._robot_coordinates = tuple: (x,y)
                self._blocks is initialized list: tuple: (x,y)
                self._storages is initialized list: tuple: (x,y)
        """
        for x in range(self.height):
            for y in range(self.width):
                letter = self.grid[x][y]
                match letter:
                    case 'R':
                        self._robot_coordinates = (x,y)
                        self._grid[x][y] = ' '
                    case 'X':
                        self._blocks.add((x,y))
                        self._grid[x][y] = ' '
                    case 'S': self._storages.add((x,y))
                    case _ if letter.isupper() and letter not in {'O','S','R'}:
                        #self._paired_entities[letter] = (x,y)
                        self._paired_block_coords[(x,y)] = letter
                        self._grid[x][y] = ' '
                    case _ if letter.islower():
                        self._paired_entities[letter] = (x,y)
                        self._paired_storage_coords[(x,y)] = letter
    
    def entity_at(self,x,y):
        '''Returns the top-down visible entity.'''
        if not self.in_bounds(x,y):
            return Entity.OBSTACLE

        letter = self.grid[x][y]
        match letter:
            case 'O': return Entity.OBSTACLE
            case 'S': return Entity.STORAGE
            case _ if (x,y) == self._robot_coordinates: return Entity.ROBOT
            case _ if (x,y) in self._blocks: return Entity.BLOCK
            case _ if (x,y) in self._paired_block_coords: return Entity.BLOCK_PAIRED
            case _ if (x,y) in self._paired_storage_coords: return Entity.STORAGE_PAIRED
            case default: return Entity.EMPTY
            
