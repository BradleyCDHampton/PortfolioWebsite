import pytest
import numpy as np
from pathlib import Path

from game_state import State, Direction
from puzzle import Puzzle

#Setup

all_puzzles = []
puzzles_directory = Path('sokomind\puzzles')
     
for puzzle_path in puzzles_directory.iterdir():
    new_puzzle = Puzzle(puzzle_path)
    all_puzzles.append(new_puzzle)

#Tests

@pytest.fixture
def tiny():
    return Puzzle(r"sokomind\puzzles\1_tiny.txt")

@pytest.fixture
def push_demo():
    return State(Puzzle(r"sokomind\puzzles\5_test_pushing.txt"))

def test_constructor(tiny):
    my_state = State(tiny)

    # Check whether the superclass was properly initialized...
    assert np.array_equal(my_state.grid, tiny.grid)
    assert (my_state.grid is tiny.grid) == False

    assert my_state.dimensions == tiny.dimensions
    assert my_state.height == tiny.height
    assert my_state.width == tiny.width
    assert my_state.starting_coordinates == tiny.starting_coordinates
    assert my_state.storages == tiny.storages
    assert my_state.blocks == tiny.blocks
    assert my_state.paired_entities == tiny.paired_entities

    # Check where these new members were initialized correctly
    assert my_state.parent == None
    assert my_state.successors == []
    assert my_state.moves == []
    assert my_state.move_number == 0

def test_validity_checks_walking(tiny):
    test_state = State(tiny)
    assert test_state.is_valid_move(Direction.NORTH) == False
    assert test_state.is_valid_move(Direction.SOUTH) == False
    assert test_state.is_valid_move(Direction.EAST) == True
    assert test_state.is_valid_move(Direction.WEST) == True

def test_validity_checks_pushing(push_demo):
    test_state = State(push_demo)
    assert test_state.is_valid_move(Direction.NORTH) == False
    assert test_state.is_valid_move(Direction.SOUTH) == False
    assert test_state.is_valid_move(Direction.EAST) == True
    assert test_state.is_valid_move(Direction.WEST) == True

def test_generate_state_walking(tiny):
    test_state = State(tiny)

    state_move_east = test_state._generate_successor(Direction.EAST)
    east_actual = Puzzle(r"expected\1_tiny_E.txt")

    assert np.array_equal(state_move_east.grid, east_actual.grid)

    assert test_state.move_number == 0
    assert state_move_east.move_number == 1 and state_move_east.moves == [Direction.EAST]
    assert state_move_east._robot_coordinates == (test_state._robot_coordinates[0], test_state._robot_coordinates[1]+1)

    assert len(state_move_east.blocks) == len(test_state.blocks)
    assert state_move_east.blocks == test_state.blocks 
    assert state_move_east.blocks is not test_state.blocks
    assert state_move_east.paired_entities == test_state.paired_entities
    assert state_move_east.paired_entities is test_state.paired_entities


def test_generate_state_pushing(push_demo):
    test_state = State(push_demo)

    state_move_east = test_state._generate_successor(Direction.EAST)

    east_actual = Puzzle(r"expected\5_test_pushing_E.txt")

    assert test_state.move_number == 0
    assert state_move_east.move_number == 1 and state_move_east.moves == [Direction.EAST]
    assert state_move_east._robot_coordinates == (test_state._robot_coordinates[0], test_state._robot_coordinates[1]+1)
  
    assert len(state_move_east.blocks) == len(test_state.blocks)
    assert (state_move_east.blocks != test_state.blocks or
            state_move_east.paired_entities != test_state.paired_entities)

def test_generate_successors(tiny):
    test_state = State(tiny)
    assert len(test_state.successors) == 0

    test_state.generate_successors()
    assert len(test_state.successors) == 2

def test_object_permenance():
    perm = Puzzle(r"sokomind\puzzles\4_test_permanence.txt")
    test_state = State(perm)

    curr_state = test_state

    for i in range(3):
        curr_state = curr_state._generate_successor(Direction.NORTH)
        print(curr_state._robot_coordinates)
    for i in range(3):
        print(curr_state._robot_coordinates)
        curr_state = curr_state._generate_successor(Direction.SOUTH)
    
    assert curr_state._robot_coordinates == test_state._robot_coordinates
    assert curr_state.move_number == 6
    assert np.array_equal(test_state._grid, curr_state._grid)
    assert curr_state.moves == [Direction.NORTH, Direction.NORTH, Direction.NORTH,
                               Direction.SOUTH, Direction.SOUTH, Direction.SOUTH]
    
@pytest.mark.parametrize("puzzle", all_puzzles)
def test_is_not_solved(puzzle):
    test_state = State(puzzle)
    assert test_state.is_solved() == False


def test_solve(push_demo):
    curr_state = State(push_demo)

    plan = [Direction.EAST, Direction.NORTH, Direction.WEST, Direction.SOUTH,
            Direction.WEST, Direction.SOUTH, Direction.EAST, Direction.SOUTH,
            Direction.WEST, Direction.WEST, Direction.WEST, Direction.NORTH,
            Direction.NORTH, Direction.NORTH, Direction.EAST, Direction.SOUTH,
            Direction.WEST, Direction.SOUTH, Direction.EAST] 

    for step in plan:
        curr_state = curr_state._generate_successor(step)
        
    assert curr_state.is_solved() == True

def test_copy_references(tiny):
    original_state = State(tiny)
    next_state = original_state._generate_successor(Direction.EAST)

    assert original_state._storages is next_state._storages
    assert original_state._paired_storage_coords is next_state._paired_storage_coords
    
    assert original_state._blocks is not next_state._blocks
    assert next_state._parent is original_state
   
    #assert self._paired_entities = {}
    assert original_state._grid is next_state._grid


    """


      
      
    
    """



## Test use assignment on grid

#