import queue
from game_state import State
from collections import deque


def dfs(initial_state: State):
    """
    Depth-First Search

    Param:
        initial_state: State; the first state of a puzzle.
    
    Returns: Solution State, number of visited States
    """
    visited_states = set()
    state_queue = deque([initial_state])

    while state_queue:
        state = state_queue.pop()
        if state.is_solved():
            return state, len(visited_states)
        elif state not in visited_states:
            visited_states.add(state)
            state.generate_successors()
            for successor in state.successors:
                if successor not in visited_states:
                    state_queue.append(successor)

    return None, len(visited_states)


def bfs(initial_state: State):
    """
        Bread-First Search

     Param:
        initial_state: State; the first state of a puzzle.
    
        Returns: Solution State, number of visited States
    """

    visited_states = set()
    state_queue = deque([initial_state])

    while state_queue:
        state = state_queue.popleft()
        if state.is_solved():
            return state, len(visited_states)
        elif state not in visited_states:
            visited_states.add(state)
            state.generate_successors()
            for successor in state.successors:
                if successor not in visited_states:
                    state_queue.append(successor)
    return None, len(visited_states)


def greedy(heuristic_func, a_star=False):
    """
        A wrapper function, which produces either an A* or Greedy Search function with
        incorportating a given heuristic function.

        Parameters:
            heuristic_func: A function(State: State, HeuristicData: Any) -> int, usually from sokomind_heuristics.py
            a_star: bool, True to change the Greedy Algorithm to A*, False otherwise

        Returns: A function, using the specified Heuristic Function.
    """

    if a_star == True:
        # Wraps the heuristic function in a function that also adds in the path cost.
        heuristic_func_without_cost = heuristic_func
        heuristic_func = lambda state, heuristic_data: (-1 if heuristic_func_without_cost(state, heuristic_data) == -1
                                                        else heuristic_func_without_cost(state, heuristic_data) + state.move_number)

    def greedy_with_heuristic(initial_state: State):
        '''Actual logic for the Greedy Algorithm. The Heuristic Function is defined in the outer scope.'''

        visited_states = set()
        fringe = queue.PriorityQueue()
        heuristic_data = {}

        initial_cost = heuristic_func(initial_state, heuristic_data)
        fringe.put((initial_cost, initial_state))

        while not fringe.empty():
            _, state = fringe.get()
            if state.is_solved():
                return state, len(visited_states)
            elif state not in visited_states:
                visited_states.add(state)
                state.generate_successors()
                for successor in state.successors:
                    if successor not in visited_states:
                        cost = heuristic_func(successor, heuristic_data)
                        if cost >= 0: # heuristic_func may return -1 to indicate a state must be pruned.
                            fringe.put((cost, successor))
                state.successors.clear()

        return None, len(visited_states)

    return greedy_with_heuristic
