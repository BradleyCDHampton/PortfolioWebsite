
from puzzle import Entity
from game_state import State, Direction
import numpy as np
from puzzle import Entity
from collections import deque

def manhattan(state: State, heuristic_data=None):
    """
        This heuristic will be used to estimate how many moves a current state is from the goal state.
        Your implementation should calculate the sum of Manhattan distances between each box that has yet
        to be stored and the storage nearest to it. Ignore the positions of obstacles in your calculations
        and assume that many boxes can be stored at one location.

        params:
            state: State; the state we are evaluating
            heuristic_data: Any; unused for this function, included so all Heuristics would have the same blueprint.

        Returns: int; The sum of all manhattan distances between a block and its nearest storage.

    """

    def _manhattan_distance(a, b):
        '''Returns the manhattan positions between 2 tuples: int'''
        return abs(a[0]-b[0]) + abs(a[1]-b[1])

    manhattan_sum = 0
    for block in state.blocks:
        local_minimum = state.height * state.width
        for storage in state.storages:
            local_minimum = min(local_minimum, _manhattan_distance(block, storage))
        manhattan_sum += local_minimum
    for coords, val in state._paired_block_coords.items():
        compare = state._paired_entities[val.lower()]
        manhattan_sum += _manhattan_distance(coords, compare)

    return manhattan_sum

def heatmap(state: State, heuristic_data):
    """
        Similar to Manhattan. Constructs a heatmap using a bfs algorithm
        to calculate how many moves away each block is from its nearest goal
        while also navigating around Obstacles.

        params:
            state: State; the state we are evaluating
            heuristic_data: dictionary; either None or pregenerated heatmaps

        Returns: int; The sum of all steps between a block and its nearest storage, navigating around
                    obstacles.

    """
    if len(heuristic_data) == 0:
        heuristic_data.update(_generate_heatmaps(state))
        #print(heuristic_data)

    result = 0
    for (x, y) in state._blocks:
        result += heuristic_data['X'][x][y]
    for (x, y), val in state._paired_block_coords.items():
        result += heuristic_data[val][x][y]

    return result

def deadzones(state: State, heuristic_data=None):
    """
        Extension of heatmap.
        After generating the initial heatmap, evaluates cells where a block will get stuck
        with no possible way to reach its goal.

        During invocation of the Heuristic, if the a block is in a spot where it will no longer
        be able to reach its goal, a value of -1 is returned, which will cause the state to be pruned.

        Further analysis is shared in README.md

        Returns: Sum of all steps between a block and its nearest storage, navigating around obstacles...
                 OR -1, if the Puzzle is unsolvable from this State.
    """
    
    # check for whether any blocks can never move & aren't on goal
    for block in state._blocks:
        if block not in state._storages and _can_never_move(state, block, set()):
            return -1
    for coords, block in state._paired_block_coords.items():
        if state._paired_entities[block.lower()] != coords and _can_never_move(state, coords, set()):
            return -1
        
    # Checks if any Storage is Functionally "blocked off" and could never recieve their designated block.    
    for storage in state._storages:
        if storage not in state._blocks and _cannot_recieve_block(state, storage):
            return -1
    for coords, storage in state._paired_storage_coords.items():
        if ((coords not in state._paired_block_coords or
            state._paired_block_coords[coords].lower() != storage) and
            _cannot_recieve_block(state, coords)):
            return -1
    
    
    # Checks if a Block was just pushed into an Area that the robot will never be able to push it out of.
    if state._parent is not None:

        dx,dy = state._last_move.value
        x,y = state._robot_coordinates

        if (state.entity_at(dx+x,dy+y) in {Entity.BLOCK, Entity.BLOCK_PAIRED} and
        state._parent.is_passable(dx+x,dy+y) and 
        _cannot_reach_robot_or_storage(state, (dx+x, dy+y))):
            return -1

    # Generates a Deadzone Map, if one does not already exist. (heuristic_data persists between calls to this function)
    if len(heuristic_data) == 0:
        heuristic_data.update(_generate_deadzones(state))
    
    # Checks whether any block is in a Deadzone
    result = 0
    for (x, y) in state._blocks:
        local_cost = heuristic_data['X'][x][y]
        if local_cost == -1: return -1
        result += local_cost
    for (x, y), val in state._paired_block_coords.items():
        local_cost = heuristic_data[val][x][y]
        if local_cost == -1: return -1
        result += local_cost
    return result

## Helper Functions

def _generate_one_heatmap(state: State, coord_list):
    """
        Generates a grid for a given list of coordinates, where
        each cell contains a number indicating the minimum steps between itself,
        and the nearest coordinate in the coord_list, considering navigation around
        obstacles.
    """
    hm = np.full(state.dimensions, -1)
    neighbors = deque(coord_list)
    cost = 0
    while neighbors:
        
        entries = len(neighbors)
        while entries > 0:
            next_coords = neighbors.popleft()
            
            x, y = next_coords[0], next_coords[1]
            hm[x][y] = cost
            entries -= 1
            for coords_set in [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]:
                x, y = coords_set[0], coords_set[1]
                if (state.in_bounds(x,y) and hm[x][y] == -1 and
                    state.entity_at(x,y) is not Entity.OBSTACLE):
                    neighbors.append((x,y))
        cost += 1
    return hm

def _generate_heatmaps(state: State):
    """
        Generates all heatmaps required for a given Puzzle.

        Returns: a map of heatmaps, indexed by the block it is associated with.
    """
        # Generate heatmaps for X
    all_hms = {} 
    
    all_hms['X'] = _generate_one_heatmap(state, state._storages)
    for coords, val in state._paired_storage_coords.items():
        all_hms[val.upper()] = _generate_one_heatmap(state, [coords])
    return all_hms

def _generate_deadzones(state: State):
    """
        Generates a heatmap for each Block, but with a
        -1 in the spaces where a Deadzone is detected.
    
        More information on how this is evaluated is found in the README.md

        Returns: a map of heatmaps, indexed by the block it is associated with.
    """

    dz = _generate_heatmaps(state)

    # check every row for deadzones
    
    for x in range(state.height):
        last_obstacle_y = None
        storages_seen = set()
        for y in range(state.width):
            match state.entity_at(x,y):
                case Entity.OBSTACLE:
                    if last_obstacle_y is not None:
                        for key, heatmap in dz.items():
                            if not key in storages_seen:
                                for y_overwrite in range(last_obstacle_y+1, y):
                                    heatmap[x][y_overwrite] = -1
                    last_obstacle_y = y
                case Entity.STORAGE:
                    storages_seen.add('X')
                case Entity.STORAGE_PAIRED:
                    storages_seen.add(state.grid[x][y].upper())
            if (state.in_bounds(x-1,y) and state.entity_at(x-1,y) != Entity.OBSTACLE and
                        state.in_bounds(x+1,y) and state.entity_at(x+1,y) != Entity.OBSTACLE):
                last_obstacle_y = None
                storages_seen.clear()
    
    # check every column for deadzones
   
    for y in range(state.width):
        last_obstacle_x = None
        storages_seen = set()
        for x in range(state.height):
            match state.entity_at(x,y):
                case Entity.OBSTACLE:
                    if last_obstacle_x is not None:
                        for key, heatmap in dz.items():
                            if not key in storages_seen:
                                for x_overwrite in range(last_obstacle_x+1, x):
                                    heatmap[x_overwrite][y] = -1
                    last_obstacle_x = x
                case Entity.STORAGE:
                    storages_seen.add('X')
                case Entity.STORAGE_PAIRED:
                    storages_seen.add(state.grid[x][y].upper())
            if (state.in_bounds(x,y-1) and state.entity_at(x,y-1) != Entity.OBSTACLE and
                    state.in_bounds(x,y+1) and state.entity_at(x,y+1) != Entity.OBSTACLE):
                last_obstacle_x = None
                storages_seen.clear()
    return dz

def _can_never_move(state: State, coords, checked):
    """
        Determines whether a block at given coordinates can ever be pushed,
        including for the possibility of nearby blocks being pushed in the future.

        Params:
            coords: (int,int); The coordinates of the block we are investigating
            checked: set(); The blocks that we have already checked in a recursive call.

        Returns: True, if no sequence of moves can ever mean that this block can be pushed.
                 False, otherwise.
    
    """
    x, y = coords

    if coords in checked:
        return True
    elif state.is_passable(x,y):
        return False
    elif not state.is_pushable(x,y):
        return True
    
    checked.add(coords)

    v_blocked = _can_never_move(state, (x+1,y), checked) or _can_never_move(state, (x-1,y), checked)
    h_blocked = _can_never_move(state, (x,y+1), checked) or _can_never_move(state, (x,y-1), checked)

    return v_blocked and h_blocked


def _cannot_recieve_block(state: State, coords):
    """
        Determines whether a storage at given coordinates can ever have a block be pushed into it,
        including for the possibility of nearby blocks being pushed in the future.

        Param:
            coords: The coordinates of the storage we are investigating.

        Returns: True, if no sequence of moves can ever mean this storage can recieve a block.
                 False, otherwise.
    
    """
    x,y = coords
    for direction in Direction:
        dx, dy = direction.value
        if (not _can_never_move(state, (dx+x,dy+y), set()) and
            not _can_never_move(state, (2*dx+x,2*dy+y), set())):
            return False
    return True



def _cannot_reach_robot_or_storage(state: State, block_coords):
    """
        Evaluates whether a Block has just been pushed into an area that will later cause
        the robot to revisit a state, or create an unsolvable scenario.
    
        Param: 
            state: The state we are checking the Heuristic value of.
            block_coords: (int,int); the block we are investigating.
    
        Returns: True if it is impossible the robot to move to a diffreent
                 adjacent edge of this block AND if the robot continuing to push
                 it in the direction it is currently facing will not lead to the block
                 being pushed into its storage.
    """

    bx,by = block_coords
    target_storage = None

    # Checks whether the block in question is already in its designated storage.
    match state.entity_at(bx, by):
        case Entity.BLOCK:
            if block_coords in state._storages:
                return False
            target_storage = 'S'
        case Entity.BLOCK_PAIRED:
            letter = state.grid[bx][by]
            if letter.lower() == state._grid[bx][by]:
                return False
            target_storage = letter.lower()

    def _recursive_cannot_reach_robot_or_storage(state, target_storage, search_coords, temp):
        """
            Performs a bfs of an adjacent spaces from the starting block.
            Returns: False if the bfs visits the original block's designated Storage, OR the Robot.
                     True otherwise.
        """

        sx, sy = search_coords

        if search_coords in temp:
            return True  
        temp.add(search_coords)

        if not state.is_passable(sx, sy):
            return True
        if state._robot_coordinates == search_coords:
            return False
        if state._grid[sx][sy] == target_storage:
            return False
        return (_recursive_cannot_reach_robot_or_storage(state, target_storage, (sx+1, sy), temp) and 
                _recursive_cannot_reach_robot_or_storage(state, target_storage, (sx-1, sy), temp) and
                _recursive_cannot_reach_robot_or_storage(state, target_storage, (sx, sy+1), temp) and
                _recursive_cannot_reach_robot_or_storage(state, target_storage, (sx, sy-1), temp))

    for direction in Direction:
        dx, dy = direction.value
        # Checks the 3 adjacent spaces of the block, not including the one the robot is currently on.
        if (((dx+bx,dy+by) != state._robot_coordinates) and state.is_passable(-1*dx+bx,-1*dy+by) and
            not _recursive_cannot_reach_robot_or_storage(state, target_storage, (dx+bx,dy+by), set())):
            return False

    return True


