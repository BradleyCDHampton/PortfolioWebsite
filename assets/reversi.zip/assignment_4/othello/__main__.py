from othello import Othello
from algorithms import mini_max, alpha_beta
from heuristics import pieces, frontier_disks, positions, aggregate
import argparse


# Command Line Arguments
parser = argparse.ArgumentParser(prog='__main__.py')
parser.add_argument('--n', type=int, default=8, 
                    help='The size of the square Othello grid.')
parser.add_argument('--ply', type=int, default=4, 
                    help='The amount of moves that the AI should look ahead.')
parser.add_argument('algorithm', choices = ['minimax','alphabeta'],
                    help="The algorithm that is used to control the search space for the AI")
parser.add_argument('heuristic', choices = ['count','frontier','positions', "aggregate"],
                     help="The heuristic function that should be used for the AI to evaluate a grid.")

def main():
    args = parser.parse_args()

    # Determine what algorithm to use based on Cmdline Args
    chosen_algorithm = None
    match args.algorithm:
        case 'minimax': chosen_algorithm = mini_max
        case 'alphabeta': chosen_algorithm = alpha_beta

    # Determine what Heuristic Function to use based on cmdline args
    chosen_heuristic = None
    match args.heuristic:
        case 'count': chosen_heuristic = pieces
        case 'frontier': chosen_heuristic = frontier_disks
        case 'positions': chosen_heuristic = positions
        case 'aggregate': chosen_heuristic = aggregate
       
    new_game = Othello(args.n, chosen_algorithm, args.ply, chosen_heuristic)
    new_game.run()

if __name__ == "__main__":
    main()

# TODO
"""
    1. alphabeta pruning seems to be producing bad results, it plays significantly worse than minimax
    2. any additional heuristics
    3. The report, which I hate.
"""

