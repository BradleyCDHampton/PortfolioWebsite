from chip import Chip
import math

def mini_max(state, ai_chip, heuristic_func, depth):
    """
        Implementation of the Mini-Max Algorithm

        params:
            state: Grid - The grid, at the moment where the AI needs to make a move.
            ai_chip: Chip - The Chip (Black or White) that the AI is playing for.
            heuristic_func: func(Grid, Chip) -> int - The Heuristic Function we are using for this algorithm.
            depth: int - The number of moves that the AI will look ahead.

        Returns: tuple(int, int) - the coordinates of the move that the AI should make.
    """
    def _recursive_mini_max(state, chip_turn, depth):
        if state.is_game_over() or depth == 0: # Game over state
            return heuristic_func(state, ai_chip)
        else:
            successors = state.generate_successors(chip_turn)
            next_turn = Chip.BLACK if chip_turn == Chip.WHITE else Chip.WHITE

            min_or_max = min if ai_chip != chip_turn else max
            best_lookahead = min_or_max(_recursive_mini_max(child, next_turn, depth-1) for child in successors)

            return best_lookahead
    
    # Get the legal moves for this next move
    legal_moves = state.get_legal_moves(ai_chip)
    opponent_chip = Chip.BLACK if ai_chip == Chip.WHITE else Chip.WHITE

    # Evaluate the Heuristic with each of these potential moves
    moves = {(i,j) : _recursive_mini_max(state.generate_successor(i,j, ai_chip),
                                         opponent_chip, depth) for i,j in legal_moves}

    # Determine which move leads to the best score.
    best_move = max(moves, key=moves.get)
    return best_move


def alpha_beta(state, ai_chip, heuristic_func, depth):
    """
        Implementation of the Alpha-Beta Pruning

        params:
            state: Grid - The grid, at the moment where the AI needs to make a move.
            ai_chip: Chip - The Chip (Black or White) that the AI is playing for.
            heuristic_func: func(Grid, Chip) -> int - The Heuristic Function we are using for this algorithm.
            depth: int - The number of moves that the AI will look ahead.

        Returns: tuple(int, int) - the coordinates of the move that the AI should make.
    """
    # Get the legal moves for this next move
    legal_moves = state.get_legal_moves(ai_chip)
    opponent_chip = Chip.BLACK if ai_chip == Chip.WHITE else Chip.WHITE

    def _recursive_alpha_beta(state, depth, alpha, beta, curr_player):
        if depth == 0 or len(state.get_legal_moves(curr_player)) == 0:
            return heuristic_func(state, ai_chip) 
        if ai_chip == curr_player:
            for child in state.generate_successors(curr_player):
                alpha = max (alpha, _recursive_alpha_beta(child, depth-1, alpha, beta, opponent_chip))
                if beta <= alpha:
                    break # beta cut-off
            return alpha
        else:
            for child in state.generate_successors(curr_player):
                beta = min(beta, _recursive_alpha_beta(child, depth-1, alpha, beta, ai_chip))
                if beta <= alpha:
                    break
            return beta # alpha cut-off

    # Evaluate the Heuristic with each of these potential moves
    moves = {(i,j) : _recursive_alpha_beta(state.generate_successor(i,j, ai_chip),
                                         depth-1, -math.inf, math.inf, opponent_chip) for i,j in legal_moves}

    # Determine which move leads to the best score.
    best_move = max(moves, key=moves.get)
    return best_move