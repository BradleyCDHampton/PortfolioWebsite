from chip import Chip
import math

def pieces(grid, chip):
    """
        Intuititive Heuristic: Attempts to have more pieces on the board than the opponent.

        Param:
            grid: [[Chip]] - The state of the grid we are evaluating
            chip: Chip - The player score that we are trying to maximize

        Returns:
            int: The count of the chips on the grid, minus the count of its opponents
                 chips on the grid.
    """
    black_score, white_score = grid.get_scores()
    evaluation = white_score - black_score

    if chip == Chip.BLACK: 
        evaluation *= -1
        
    return evaluation

def frontier_disks(grid, chip):
    """
        Puts a higher value on tiles that have less chances to be taken back.

        Param:
            grid: [[Chip]] - The state of the grid we are evaluating
            chip: Chip - The player score that we are trying to maximize

        Returns:
            int: how many more frontiers .
    """
    # count frontier disks for each player

    if grid.is_game_over():
        return math.inf if pieces(grid, chip) > 0 else -math.inf

    n = len(grid._internal_grid)
    black_frontiers = 0
    white_frontiers = 0

    def count_frontiers(grid, i, j):
        '''Returns the number of empty tiles adjacent to a specific cell.'''
        directions = [(1,0),(-1,0),(0,1),(0,-1),
                      (-1,-1),(1,1),(-1,1),(1,-1)]
        count = 0

        for dx, dy in directions:
            if grid.in_grid(dx+i,dy+j) and grid._internal_grid[dx+i][dy+j] == Chip.EMPTY:
                count += 1
        return count

    for i in range(n):
            for j in range(n):
                match grid._internal_grid[i][j]:
                    case Chip.BLACK:
                        black_frontiers += count_frontiers(grid, i, j)
                    case Chip.WHITE:
                        white_frontiers += count_frontiers(grid, i, j)

    evaluation = white_frontiers - black_frontiers
    if chip == Chip.BLACK:
        evaluation *= -1
    
    return evaluation

        
def positions(grid, chip):
    """
        Param:
            grid: [[Chip]] - The state of the grid we are evaluating
            chip: Chip - The player score that we are trying to maximize

        Returns:
            int: (please remember to update) heuristic evaluation score.
    """
    # weight by the "value" of each position

    if grid.is_game_over():
        return math.inf if pieces(grid, chip) > 0 else -math.inf
    
    n = len(grid._internal_grid)
    black_score = 0
    white_score = 0

    for i in range(n):
        for j in range(n):
            value = 1
            if (i == 0 or i == n-1):
                value *= (n//2)
            if (j == 0 or j == n-1):
                value *= (n//2)

            match grid._internal_grid[i][j]:
                case Chip.BLACK:
                    black_score += value
                case Chip.WHITE:
                    white_score += value

    evaluation = black_score - white_score
    if chip == Chip.WHITE:
        evaluation *= -1
    
    return evaluation

def aggregate(grid, chip):
    '''Evaluated as the summation of all other Heuristic functions.'''
    return pieces(grid, chip) + frontier_disks(grid, chip) + positions(grid, chip)
 

