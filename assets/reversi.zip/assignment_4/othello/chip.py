from enum import Enum

class Chip(Enum):
    '''The entity that occupies each slot in a Othello Grid'''
    EMPTY = 0
    BLACK = 1
    WHITE = 2
    BLACK_M = 3