
from graphics import Graphics
from grid import Grid
from chip import Chip
import time

class Othello:
    """
    
    """
    def __init__(self, n, algorithm, ply, heuristic):
        """
        
        """
        self._grid = Grid(n)
        self._graphics = Graphics(n)
        self._initialize_grid(n)
        self._wire_buttons()
        self._mutex = True

        # AI's Decision Making Functions
        self._algorithm = algorithm
        self._ply = ply
        self._heuristic = heuristic
        self._AI_turns = 0
        self._AI_total_turn_time = 0
        self._AI_longest_turn_time = 0


    def place_chip(self, i, j, chip: Chip):
        """
            Precondition: Chip is BLACK or WHITE, not any other enum
        """
        flipped_chips = self._grid.set_chip(i, j, chip) # the heuristic can do look-ahead w/ the nongraphical grid
        self._graphics.set_image(flipped_chips, chip, self._grid.get_legal_moves(Chip.BLACK))
        #print(f"Legal moves for Black: {self._grid.get_legal_moves(Chip.BLACK)}")
        #print(f"Legal moves for White: {self._grid.get_legal_moves(Chip.WHITE)}")


    def _end_game(self):
        '''Announces that the Game is over and outputs the final score and AI time stats into the Console.'''
        print("The Game is Over...")
        black_score, white_score = self._grid.get_scores()
        print(f"Score | Black: {black_score}, White {white_score}")
        print(f"Average AI Turn: {self._AI_total_turn_time/self._AI_turns} sec.")
        print(f"Longest AI Turn: {self._AI_longest_turn_time} sec.")


    def _initialize_grid(self, n):
        """
            Creates an nxn board with the inner 4 chips configured as per the start of an Othello game.

            Preconditions:
                n == len(self._grid) and len(self._grid[0]) and
                n == len(self._graphics._buttons) and n == len(self._graphics._buttons[0]) and
                
            Postcondition:
                The inner 4 chips are configured to reflect the start of an Othello game.
                (i.e. the center 4 chips are [[Chip.BLACK, Chip.WHITE],[Chip.WHITE, Chip.BLACK]])
                This is reflected in both the grid and in the graphical UI.

        """
        for i in range(n//2-1,n//2+1):
            for j in range(n//2-1,n//2+1):
                chip = Chip.BLACK if i == j else Chip.WHITE
                self.place_chip(i, j, chip)
    
    def on_click(self, i, j):
        """



        """
        if not self._mutex: # Lazy implementation of a Mutex
            return

        self._mutex = False

        if (i, j) in self._grid.get_legal_moves(Chip.BLACK):
            self.place_chip(i,j,Chip.BLACK)
            self._graphics.root.update()
        
            while self._grid.has_legal_moves(Chip.WHITE):

                ai_move_start = time.time()
                ri, rj = self._algorithm(self._grid, Chip.WHITE, self._heuristic, self._ply)
                ai_move_end = time.time()

                curr_ai_time = ai_move_end - ai_move_start
                self._AI_total_turn_time += curr_ai_time
                self._AI_longest_turn_time = max(self._AI_longest_turn_time, curr_ai_time)
                self._AI_turns += 1

                self.place_chip(ri,rj,Chip.WHITE)
                print(f"Time for AI to make a move: {curr_ai_time} sec.")
                
                if self._grid.has_legal_moves(Chip.BLACK):
                    break
            
            if self._grid.is_game_over():
                self._end_game()
            
        self._mutex = True
       
            
    def _wire_buttons(self):
        """
            Makes each button in the UI respond to user clicks.

            Precondtion:
                self._graphics._buttons is an n x n grid of Buttons (n>3)
                
            PostCondition:
                Each button is connected to a thread, where clicking the button
                activates self.on_click(i,j) where i,j is the coordinates of the button
                referenced in self._graphics._buttons.
        """
        n = len(self._graphics._buttons)

        for i in range(n):
            for j in range(n):
                button = self._graphics._buttons[i][j]
                button.config(command=lambda i=i, j=j: self.on_click(i,j))

    def run(self):
        '''Launches the application'''
        self._graphics.root.mainloop()