
from chip import Chip
from collections import defaultdict
import copy

class Grid:
    """
        The internal (logical) Grid for an Othello game.
    """

    def __init__(self, n):
        """
            Initializes the grid.

            Precondition:
                n: int - The size of the square Grid
            
            Postcondition:
                The Grid is of size nxn and each cell in the Grid
                is filled with Chip.EMPTY
        """
        self._internal_grid = [[Chip.EMPTY for _ in range(n)] for _ in range(n)]
        self._legal_moves = defaultdict(None)
       
        self.chips = defaultdict(set)
        self.chips[Chip.EMPTY] = self._initialize_open_slots(n)


    def _initialize_open_slots(self, n):
        '''Returns a set of coordinates including every possible coordinate in the Grid'''
        return {(i, j) for i in range(n) for j in range(n)}

    def set_chip(self, i, j, chip: Chip):
        """
            Sets a Chip into the Grid, flipping any flanked opponent Chips.

            params:
                i: int - The row the chip is placed into.
                j: int - The column the chip is placed into.
                chip: Chip - the color of the chip to be placed into the grid.

            Returns:
                to_flip: {(int,int)} - The set of coordinates of Chips that are flipped, including the coordinates
                    (i,j), which is the coordinates Chip that this function was invoked with.
        """
        # Remove this from the possible moves.
        self.chips[Chip.EMPTY].remove((i,j))
        self.chips[chip].add((i,j))

        # Plan to put this chip into the grid.
        to_flip = set()
        to_flip.add((i,j))

        # Figure out which chips are flanked by this.
        directions = [(1,0),(-1,0),(0,1),(0,-1),
                      (-1,-1),(1,1),(-1,1),(1,-1)]
        
        opponent_chip = Chip.WHITE if chip == Chip.BLACK else Chip.BLACK

        for di, dj in directions:
            potential_flip = set()
            k = 1
            while (self.in_grid(k*di+i, k*dj+j) and 
                   self._internal_grid[k*di+i][k*dj+j] == opponent_chip):
                potential_flip.add((k*di+i, k*dj+j))
                k += 1
            if (self.in_grid(k*di+i, k*dj+j) and
                self._internal_grid[k*di+i][k*dj+j] == chip and
                k > 1):
                to_flip = to_flip.union(potential_flip)           

        # Change all the chips we need to change.
        for x, y in to_flip:
            self._internal_grid[x][y] = chip

        # Legal moves are stale.
        self._legal_moves[Chip.BLACK] = None
        self._legal_moves[Chip.WHITE] = None

        return to_flip


    def in_grid(self, i, j):
        '''Returns True if (i,j) is indexed in the grid'''
        n = len(self._internal_grid)
        return not (i < 0 or i >= n or j < 0 or j >= n)


    def is_legal_move(self, coords, player):
        """
            Evaluates whether a move for specific coords are legal or not for a given player.

            params:
                coords: (int,int) - the coordinates we are checking a legal move for.
                player: Chip - the player we are considering a legal move for.

            Returns:
                True (if self.in_grid(i,j) and
                    (i,j) is adjacent to an opponents chip and
                    (i,j) flanks an opponents chip)
                False otherwise.
        """
        x, y = coords
        opponent_chip = Chip.WHITE if player == Chip.BLACK else Chip.BLACK

        if not self.in_grid(x,y) or self._internal_grid[x][y] != Chip.EMPTY:
            return False

        directions = [(1,0),(-1,0),(0,1),(0,-1),
                      (-1,-1),(1,1),(-1,1),(1,-1)]
        
        for dx, dy in directions:
            i = 1
            while (self.in_grid(i*dx+x, i*dy+y) and 
                   self._internal_grid[i*dx+x][i*dy+y] == opponent_chip):
                i += 1
            if (self.in_grid(i*dx+x, i*dy+y) and
                self._internal_grid[i*dx+x][i*dy+y] == player and
                i > 1):
                return True            
        return False

    def generate_legal_moves(self, player):
        """
            Generates the all the moves a player could make. If there are no legal moves,
            then this returns an empty set.

            params:
                player: Chip - The player we are generating the legal moves for.
            
            Returns:
                {(int,int)} - the set of all Grid States the next player will have to consider.
        """
        checked_coords = set()
        legal_moves = set()
        opponent_chip = Chip.WHITE if player == Chip.BLACK else Chip.BLACK
        opponent_chips = self.chips[opponent_chip]
        directions = [(1,0),(-1,0),(0,1),(0,-1),
                      (-1,-1),(1,1),(-1,1),(1,-1)] # will have to check boundaries

        for x, y in opponent_chips:
            for dx, dy in directions:
                adjacent_coords = (x+dx,y+dy)
                if adjacent_coords in checked_coords:
                    continue
                checked_coords.add(adjacent_coords)
                if self.is_legal_move(adjacent_coords, player):
                    legal_moves.add(adjacent_coords)
        
        return legal_moves

    def generate_successors(self, player):
        """
            Generates the grids for all the moves a player could make. If there are no legal moves,
            then this will return a deep copy of this grid to indicate that the player must pass.

            params:
                player: Chip - The player we are generating the successor states for
            
            Returns:
                {Grid} - the set of all Grid States the next player will have to consider.
        """
        successors = set()

        for i, j in self.get_legal_moves(player):
            child = copy.deepcopy(self)
            child.set_chip(i,j,player)
            successors.add(child)

        # If there are no legal moves, then the turn is passed.
        if len(successors) == 0:
            successors.add(copy.deepcopy(self))

        return successors

    def generate_successor(self, i, j, chip):
        """
            Generates a successor state that is derived from specific move.

            params:
                i: int - The row the chip will be placed into.
                j: int - The column the chip will be placed into.
                chip: Chip - The chip that was placed for this move

            Returns: Grid - the successor state.
        
        """
        state = copy.deepcopy(self)
        state.set_chip(i,j, chip)
        return state

    def get_legal_moves(self, player):
        """
            Retrieves the legal moves a player, regenerating the legal moves if not
            already cached.

            Params:
                player: Chip - The color of the player we are looking for moves for

            Returns:
                {(int,int)} - The set of all legal moves for a given player.

        """
        if self._legal_moves[player] is None:
            self._legal_moves[player] = self.generate_legal_moves(player)
        return self._legal_moves[player]


    def has_legal_moves(self, chip):
        '''Returns True if the specified player has at least one legal move.'''
        return len(self.get_legal_moves(chip)) > 0


    def is_game_over(self):
        '''Returns True if neither player has legal moves.'''
        return not (self.has_legal_moves(Chip.BLACK) or self.has_legal_moves(Chip.WHITE))


    def get_scores(self):
        """
            Tallies each player's scores for a given grid state.

            Returns:
                black_count: int - The count of black chips in the grid.
                white_count: int - The count of white chips in the grid.
        """
        n = len(self._internal_grid)
        white_count = 0
        black_count = 0
        
        for i in range(n):
            for j in range(n):
                match self._internal_grid[i][j]:
                    case Chip.BLACK:
                        black_count += 1
                    case Chip.WHITE:
                        white_count += 1
        
        return black_count, white_count