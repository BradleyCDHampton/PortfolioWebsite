from tkinter import * 
from chip import Chip

class Graphics:
    
    def __init__(self, n):
        """
            Initializes the GUI window
        
            params:
                n: int - the size of the square grid of Buttons

            Postcondition:
                The GUI is initialized to have an nxn grid of buttons.
                self._buttons is an nxn array that is logically in the same configuration
                as the actual graphics.
        """
        self.root = Tk()

        self._images = {Chip.EMPTY : PhotoImage(file = r"graphics/empty.png"),
                        Chip.BLACK : PhotoImage(file= r"graphics/black.png"),
                        Chip.WHITE : PhotoImage(file= r"graphics/white.png"),
                        Chip.BLACK_M : PhotoImage(file= r"graphics/black_marker.png")}

        self.root.geometry(f"{n*54}x{n*54}")
        self.root.title("Othello")
        self.root.configure(bg='purple')

        self._buttons = self._initialize_buttons(n)
        self._marks = set()


    def _initialize_buttons(self, n):
        """
            Generates an nxn grid of butttons.

            Precondition:
                n > 0 and self.root != None
        """
        frm = Frame(self.root)
        frm.grid(padx=0, pady=0, ipadx=0, ipady=0)

        buttons = [[Chip.EMPTY for _ in range(n)] for _ in range(n)]
        default_image = self._images[Chip.EMPTY]

        for i in range(n):
            for j in range(n):
                button = Button(self.root, image = default_image, highlightthickness=0)
                button.grid(row=i, column=j, padx=0, pady=0, ipadx=0, ipady=0)
                buttons[i][j] = button

        return buttons

    def set_image(self, coords_list, chip: Chip, legal_moves=None):
        """
            Changes out the images on each button to reflect the current game state.

            Params:
                coords_list: {(int, int)} - The set of all coordinates to be updated.
                chip: Chip - The chip (color) that each coordinate should be set to.
                legal_moves: Boolean - if True, also mark any legal moves for Black.

            Precondition:
                All coordinates in coords_list are derived from a legal move in Othello.

            Postcondition:
                The images on each of the Buttons in self._buttons are changed as appropriate. 
                if legal_moves == True, then len(self._marks) > 0 if there are legal moves for Black.
        """
        # Erase all previous marks
        for marked_button in self._marks:
            marked_button.config(image=self._images[Chip.EMPTY])
        self._marks.clear()

        # Place/flip the new chips into the GUI

        for i, j in coords_list:
            button = self._buttons[i][j]
            button.config(image=self._images[chip])

        if legal_moves == None:
            return
        
        for i, j in legal_moves:
            button = self._buttons[i][j]
            button.config(image=self._images[Chip.BLACK_M])
            self._marks.add(button)

 

