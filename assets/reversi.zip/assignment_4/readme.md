Bradley Hampton
10/31/2024
CS580 - Intro to Artificial Intelligence
Professor Li Yaohang
Old Dominion University

 # Required Installations

    Python 3.11.7
    Tkinter 8.6

 # How to Run (update before submission)

    usage: path/to/othello [-h] [--n N] [--ply PLY] {minimax,alphabeta} {count,frontier,positions}

 # Commandline Arguments (update before submission)

    {algorithm}
        (required) The file path to the empty crossword puzzle template.
        options: minimax, alphabeta

    {heuristic}
        (required) The filepath to the wordlist to be used to create the crossword.
        options: count, frontiers, 

    --ply
        (optional) The heuristic used to choose which variable (slot) we will fill in next.
        default: 4

    --n
        (optional) 
        default: 8

 # Example Executions

   python othello minimax frontiers --ply 2
   python othello minimax positions --ply 2
   python othello minimax count --ply 4 --n 6
   
   python othello alphabeta count --ply 2                EASY
   python othello alphabeta aggregate --ply 4            MEDIUM
   python othello alphabeta positions --ply 6            HARD

# Heuristic Functions

   count:
      Based on the raw count of each color of chips. Returns however many more chips a player has against
      their opponent.

   frontiers:
      For each chip in the grid, we count the number of empty spaces that are adjacent to that chip.
      We then find the difference between each player's "frontier_score" to calculate the value returned.

   positions:
      Assigns a higher value to cells on the edge of the board. The value of these cells are
      n//2, where n is the size of the board. Corners are assigned a value of (n//2)^2

   aggregate:
      A simple summation of all of the other heuristics combined.



 